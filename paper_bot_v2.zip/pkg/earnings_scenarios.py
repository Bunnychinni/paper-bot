"""What $1,000 produces IF an edge exists. CONDITIONAL - you do not have one yet."""
import numpy as np
rng=np.random.default_rng(7)

def sim(exp_pct, sd_pct=2.5, trades_yr=250, years=5, start=1000.0,
        pos_frac=0.30, n=20000, withdraw=0.0):
    eq=np.full(n,start); peak=eq.copy(); mdd=np.zeros(n); out={}
    for t in range(trades_yr*years):
        size=eq*pos_frac
        r=rng.normal(exp_pct/100, sd_pct/100, n)
        eq=np.maximum(eq+size*r,0)
        peak=np.maximum(peak,eq); mdd=np.maximum(mdd,(peak-eq)/np.maximum(peak,1e-9))
        if (t+1)%trades_yr==0: out[(t+1)//trades_yr]=(eq.copy(),mdd.copy())
    return out

print("="*78)
print("CONDITIONAL OUTCOMES -- $1,000, 3 slots, ~250 trades/yr, 30% per position")
print("These assume an edge you have NOT demonstrated. Tested signal was -0.42%.")
print("="*78)

for exp in (0.20,0.40,0.60):
    print(f"\n### expectancy {exp:.2f}% per trade "
          f"(= ${exp*3:.2f} on a $300 position)")
    res=sim(exp)
    print(f"  {'yr':<4}{'p5':>10}{'median':>11}{'p95':>12}{'med maxDD':>12}")
    for y,(eq,dd) in res.items():
        print(f"  {y:<4}${np.percentile(eq,5):>9,.0f}${np.median(eq):>10,.0f}"
              f"${np.percentile(eq,95):>11,.0f}{100*np.median(dd):>11.0f}%")
    eq1=res[1][0]
    print(f"  year-1 median GAIN: ${np.median(eq1)-1000:>+8,.0f}   "
          f"P(down after 1yr) {100*np.mean(eq1<1000):.0f}%")

print()
print("="*78)
print("THE MEASUREMENT FLOOR -- why this matters more than the numbers above")
print("="*78)
print("""
  Your gate can only DETECT expectancy >= ~0.40%/trade (gate_power.py,
  318 holdout trades, design effect 3).

  0.40%/trade at 250 trades/yr on 30% sizing is roughly a 30%/YEAR strategy.

  So: any edge weaker than "beats almost every hedge fund on earth" is
  INVISIBLE to your test. A real 0.20% edge exists, compounds, and you
  would never be able to prove it -- your gate would report FAIL.

  That is not pessimism, it is the arithmetic of small samples. It is also
  why the honest play is to accumulate trades, not to keep testing.
""")
