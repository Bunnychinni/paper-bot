"""
Options round-trip cost model. Same job as cost_model.py, for contracts.

Options are where costs go from a rounding error to the dominant term.
This computes them exactly so you can decide with numbers instead of hope.

FEES (verify against your broker; Alpaca options pricing differs by plan):
  OCC clearing    $0.02 / contract, both sides
  ORF (exchange)  ~$0.02-0.05 / contract
  SEC Sec 31      $20.60 per $1M of SALE proceeds
  FINRA TAF       $0.00279 / contract SOLD  (options rate, not the equity rate)
  Commission      $0 on many retail brokers, $0.50-0.65/contract elsewhere
"""
import math

OCC, ORF, TAF_OPT, SEC = 0.02, 0.035, 0.00279, 20.60/1_000_000
def cp(x): return math.ceil(x*100 - 1e-9)/100

def round_trip(premium, contracts, spread_pct, commission=0.0, slip_pct=0.0):
    """premium = per-share option price. Notional = premium * 100 * contracts."""
    notional = premium*100*contracts
    fees = (OCC+ORF)*contracts*2 + cp(TAF_OPT*contracts) + cp(SEC*notional) \
           + commission*contracts*2
    spread = notional*(spread_pct/100)          # full round trip crossing
    slip = notional*(slip_pct/100)*2
    tot = fees+spread+slip
    return dict(notional=notional, fees=fees, spread=spread, slip=slip,
                total=tot, pct=100*tot/notional if notional else 0)

if __name__=="__main__":
    print("="*80)
    print("ROUND-TRIP COST BY OPTION PRICE AND SPREAD  ($300 position)")
    print("="*80)
    print(f"{'premium':>9}{'contracts':>11}{'spread%':>9}{'fees$':>8}"
          f"{'spread$':>10}{'TOTAL$':>10}{'% of position':>15}")
    print("-"*80)
    for prem, sp in [(0.20,15.0),(0.50,10.0),(1.00,8.0),(2.00,6.0),
                     (5.00,4.0),(10.00,3.0)]:
        n = max(1, int(300/(prem*100)))
        r = round_trip(prem, n, sp)
        print(f"${prem:>8.2f}{n:>11}{sp:>8.1f}%{r['fees']:>8.2f}"
              f"{r['spread']:>10.2f}{r['total']:>10.2f}{r['pct']:>14.2f}%")

    print("\n  Cheap OTM contracts have the WIDEST spreads. A $0.20 option with a")
    print("  15% spread costs you 15% of the position the moment you enter and")
    print("  exit. Compare: your equity round trip was 0.12%. This is ~125x.")

    print("\n"+"="*80)
    print("BREAK-EVEN MOVE: how far the option must go just to cover cost")
    print("="*80)
    for prem, sp in [(0.20,15.0),(0.50,10.0),(1.00,8.0),(2.00,6.0),(5.00,4.0)]:
        n=max(1,int(300/(prem*100))); r=round_trip(prem,n,sp)
        print(f"  ${prem:>5.2f} premium, {sp:>4.1f}% spread -> option must rise "
              f"{r['pct']:>5.2f}% before you make $1")

    print("\n"+"="*80)
    print("THETA: what you lose per day doing nothing")
    print("="*80)
    print("  Rough approximation for a near-ATM option, decay accelerates near expiry.\n")
    print(f"  {'days to expiry':>16}{'approx daily decay':>22}")
    for dte in (30,14,7,3,1):
        # theta ~ premium * (1 - sqrt((dte-1)/dte)) for ATM, crude but directional
        decay = 1-math.sqrt(max(dte-1,0)/dte)
        print(f"  {dte:>16}{100*decay:>21.1f}%")
    print("\n  A 7-DTE option loses roughly 7%/day to time alone. Add a 10% round-trip")
    print("  spread and you need a ~17% move in the underlying option in 24 hours")
    print("  just to break even. That is the arithmetic behind the 98.7%.")
