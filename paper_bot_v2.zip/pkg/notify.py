#!/usr/bin/env python3
"""
STAGE 3 (partial) / Pushover alerts. Sends the shortlist to your phone.

  Setup: pushover.net -> create account ($5 one-time for the app, no
  subscription) -> your USER KEY is on the dashboard -> create an
  Application to get an API TOKEN. Set PUSHOVER_TOKEN and PUSHOVER_USER.

  python notify.py --from-log scan_log.txt

Silently no-ops if the env vars are absent, so the scanner never fails
because notifications are not configured.
"""
import argparse, os, sys, urllib.parse, urllib.request

def send(title, message, priority=0):
    tok, usr = os.environ.get("PUSHOVER_TOKEN"), os.environ.get("PUSHOVER_USER")
    if not tok or not usr:
        print("pushover not configured -- skipping notification")
        return False
    data = urllib.parse.urlencode(dict(
        token=tok, user=usr, title=title, message=message[:1024],
        priority=priority)).encode()
    try:
        with urllib.request.urlopen(
                "https://api.pushover.net/1/messages.json", data, timeout=15) as r:
            return r.status == 200
    except Exception as e:
        print("pushover failed:", e)
        return False

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--from-log", required=True)
    a = ap.parse_args()
    if not os.path.exists(a.from_log):
        sys.exit(0)
    lines = open(a.from_log).read().splitlines()
    try:
        i = next(i for i, l in enumerate(lines) if "CANDIDATES for next open" in l)
        body = "\n".join(l.strip() for l in lines[i+2:] if l.strip())[:900]
    except StopIteration:
        body = "scanner ran, no candidate block found"
    n = sum(1 for l in lines if l.strip().startswith(("1.", "2.", "3.")))
    send(f"Premarket scan — {n} candidate(s)",
         body or "no candidates today")
