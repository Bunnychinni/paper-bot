#!/usr/bin/env python3
"""
OPTIONS LAB -- payoff calculator + defined-risk structures + paper logger.

Three tools, one file. Nothing here places an order.

  python options_lab.py payoff  --type call --spot 50 --strike 52 --prem 1.20 --dte 7
  python options_lab.py spread  --spot 50 --long 52 --short 55 --debit 0.95 --dte 14
  python options_lab.py compare --spot 50 --dte 7
  python options_lab.py log     --db options_log.db --add "..."
  python options_lab.py status  --db options_log.db

WHY DEFINED RISK: a long call can go to zero. A vertical spread caps both
sides -- you pay less, you cap the upside, and you cannot be wiped out by
one bad session. At $1,000 that difference is the whole game, because the
strategy that survives 20 losing trades is the only one that gets to be
right on the 21st.
"""
import argparse, math, sqlite3, sys
from datetime import date, datetime, timezone

OCC, ORF, TAF, SEC = 0.02, 0.035, 0.00279, 20.60/1_000_000
def cp(x): return math.ceil(x*100 - 1e-9)/100


# ----------------------------------------------------------------- costs
def rt_cost(premium, contracts, spread_pct, commission=0.0):
    notional = premium*100*contracts
    fees = (OCC+ORF)*contracts*2 + cp(TAF*contracts) + cp(SEC*notional) \
           + commission*contracts*2
    return fees + notional*(spread_pct/100)


def theta_per_day(dte):
    """Crude ATM approximation. Directional, not a pricing model."""
    return 1 - math.sqrt(max(dte-1, 0)/dte) if dte > 0 else 1.0


def spread_guess(premium):
    """Typical retail bid-ask as % of premium. Cheap options are worst."""
    return 15.0 if premium < 0.30 else 10.0 if premium < 0.75 else \
           8.0 if premium < 1.50 else 6.0 if premium < 3.0 else 4.0


# --------------------------------------------------------------- payoffs
def payoff_long(kind, spot, strike, prem, contracts, dte, spread_pct):
    cost = rt_cost(prem, contracts, spread_pct)
    debit = prem*100*contracts
    be = strike + prem if kind == "call" else strike - prem
    be_c = strike + prem + cost/(100*contracts) if kind == "call" \
           else strike - prem - cost/(100*contracts)
    print(f"\n{'='*72}\nLONG {kind.upper()}  spot ${spot:.2f}  strike ${strike:.2f}"
          f"  premium ${prem:.2f}  {contracts}x  {dte}DTE\n{'='*72}")
    print(f"  debit paid            ${debit:>10.2f}")
    print(f"  round-trip cost       ${cost:>10.2f}   ({100*cost/debit:.1f}% of debit)")
    print(f"  MAX LOSS              ${debit+cost:>10.2f}   = 100% of the debit + cost")
    print(f"  max gain              {'unlimited' if kind=='call' else '$'+format((strike-prem)*100*contracts,'.2f')}")
    print(f"\n  break-even (textbook) ${be:>10.2f}   spot must move "
          f"{100*(be/spot-1):+.2f}%")
    print(f"  break-even (real)     ${be_c:>10.2f}   spot must move "
          f"{100*(be_c/spot-1):+.2f}%   <- includes cost")
    d = theta_per_day(dte)
    print(f"\n  theta ~{100*d:.1f}%/day  =  ${debit*d:.2f}/day doing nothing")
    print(f"  hold 3 days and do nothing -> roughly ${debit*(1-(1-d)**3):.2f} gone")
    print(f"\n  P(total loss) is high by construction: any expiry with spot "
          f"{'below' if kind=='call' else 'above'} ${strike:.2f} pays zero.")
    return dict(max_loss=debit+cost, be=be_c, cost=cost)


def payoff_vertical(spot, long_k, short_k, debit, contracts, dte, spread_pct):
    width = abs(short_k - long_k)
    net = debit*100*contracts
    cost = rt_cost(debit, contracts, spread_pct)*1.6   # two legs each way
    maxg = (width - debit)*100*contracts - cost
    be = long_k + debit + cost/(100*contracts)
    print(f"\n{'='*72}\nVERTICAL DEBIT SPREAD  long ${long_k:.2f} / short ${short_k:.2f}"
          f"  {contracts}x  {dte}DTE\n{'='*72}")
    print(f"  net debit             ${net:>10.2f}")
    print(f"  round-trip cost       ${cost:>10.2f}   (2 legs each way)")
    print(f"  MAX LOSS              ${net+cost:>10.2f}   <- CAPPED, cannot exceed this")
    print(f"  MAX GAIN              ${maxg:>10.2f}   <- also capped")
    print(f"  risk : reward         1 : {maxg/(net+cost):.2f}")
    print(f"\n  break-even            ${be:>10.2f}   spot must move "
          f"{100*(be/spot-1):+.2f}%")
    print(f"  full profit above     ${short_k:.2f}   spot must move "
          f"{100*(short_k/spot-1):+.2f}%")
    need = (maxg/(net+cost))
    print(f"\n  break-even WIN RATE   {100*1/(1+need):.1f}%  "
          f"(you must win this often just to not lose money)")
    print(f"\n  vs the naked long: you gave up unlimited upside and bought a floor.")
    print(f"  Theta hurts you less -- the short leg decays in your favour.")
    return dict(max_loss=net+cost, max_gain=maxg, be=be)


def compare(spot, dte):
    print(f"\n{'='*76}\nSAME $300, FOUR STRUCTURES  (spot ${spot:.2f}, {dte}DTE)\n{'='*76}")
    rows = [
        ("Long OTM call  (5% OTM)", 0.35, "unlimited", "100%", "high"),
        ("Long ATM call",           1.80, "unlimited", "100%", "high"),
        ("Vertical debit spread",   0.95, "capped",    "capped", "moderate"),
        ("Buy 6 shares of stock",   None, "unlimited", "~stock", "low"),
    ]
    print(f"  {'structure':<26}{'cost drag':>11}{'max gain':>12}{'max loss':>10}{'ruin risk':>11}")
    print("  " + "-"*68)
    for name, prem, mg, ml, ruin in rows:
        if prem is None:
            drag = "0.12%"
        else:
            n = max(1, int(300/(prem*100)))
            drag = f"{100*rt_cost(prem,n,spread_guess(prem))/(prem*100*n):.1f}%"
        print(f"  {name:<26}{drag:>11}{mg:>12}{ml:>10}{ruin:>11}")
    print(f"\n  The bottom row is not a joke. 6 shares of a $50 stock costs you")
    print(f"  0.12% round trip instead of 8-15%, and cannot go to zero in a week.")
    print(f"  Options are a leverage tool, and leverage cuts both directions with")
    print(f"  the cost drag charged up front either way.")


# ---------------------------------------------------------------- logger
SCHEMA = """
CREATE TABLE IF NOT EXISTS trades(
 id INTEGER PRIMARY KEY AUTOINCREMENT, opened TEXT, closed TEXT,
 underlying TEXT, structure TEXT, strikes TEXT, dte INTEGER, contracts INTEGER,
 entry_prem REAL, exit_prem REAL, quoted_spread_pct REAL, actual_slip_pct REAL,
 debit REAL, fees REAL, pnl REAL, thesis TEXT, outcome TEXT, paper INTEGER DEFAULT 1);
"""
def db(path):
    c = sqlite3.connect(path); c.executescript(SCHEMA); return c

def status(path):
    c = db(path)
    n, = c.execute("SELECT COUNT(*) FROM trades").fetchone()
    cl, = c.execute("SELECT COUNT(*) FROM trades WHERE closed IS NOT NULL").fetchone()
    if not cl:
        print(f"\n  {n} trades logged, {cl} closed. Nothing to analyse yet.")
        print("  Log at least 30 closed paper trades before drawing any conclusion.")
        return
    row = c.execute("SELECT AVG(pnl), SUM(pnl), AVG(actual_slip_pct), "
                    "SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END), SUM(fees) "
                    "FROM trades WHERE closed IS NOT NULL").fetchone()
    print(f"\n  closed {cl}  |  win rate {100*row[3]/cl:.1f}%  |  total P&L ${row[1]:.2f}")
    print(f"  avg P&L/trade ${row[0]:.2f}  |  total fees ${row[4]:.2f}")
    if row[2]:
        print(f"  avg realised slippage {row[2]:.2f}%  <- compare to what you assumed")
    print(f"\n  PAPER ONLY. Do not go live on fewer than 60 days of this.")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("payoff")
    p.add_argument("--type", choices=["call","put"], default="call")
    p.add_argument("--spot", type=float, required=True)
    p.add_argument("--strike", type=float, required=True)
    p.add_argument("--prem", type=float, required=True)
    p.add_argument("--contracts", type=int, default=0)
    p.add_argument("--dte", type=int, default=7)
    p.add_argument("--spread-pct", type=float, default=0)

    s = sub.add_parser("spread")
    s.add_argument("--spot", type=float, required=True)
    s.add_argument("--long", type=float, required=True)
    s.add_argument("--short", type=float, required=True)
    s.add_argument("--debit", type=float, required=True)
    s.add_argument("--contracts", type=int, default=0)
    s.add_argument("--dte", type=int, default=14)
    s.add_argument("--spread-pct", type=float, default=0)

    c = sub.add_parser("compare")
    c.add_argument("--spot", type=float, default=50.0)
    c.add_argument("--dte", type=int, default=7)

    st = sub.add_parser("status"); st.add_argument("--db", default="options_log.db")
    a = ap.parse_args()

    if a.cmd == "payoff":
        n = a.contracts or max(1, int(300/(a.prem*100)))
        sp = a.spread_pct or spread_guess(a.prem)
        payoff_long(a.type, a.spot, a.strike, a.prem, n, a.dte, sp)
    elif a.cmd == "spread":
        n = a.contracts or max(1, int(300/(a.debit*100)))
        sp = a.spread_pct or spread_guess(a.debit)
        payoff_vertical(a.spot, a.long, a.short, a.debit, n, a.dte, sp)
    elif a.cmd == "compare":
        compare(a.spot, a.dte)
    elif a.cmd == "status":
        status(a.db)

if __name__ == "__main__":
    main()
