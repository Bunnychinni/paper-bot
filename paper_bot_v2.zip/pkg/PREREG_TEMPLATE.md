# PRE-REGISTRATION -- fill in every section, then rename to preregistration.md
# The bot refuses to run while any TODO remains.

## 1. Mechanism
TODO: Who is on the other side of this trade losing money on purpose, and why?
(If you cannot name them, you have a pattern, not an edge.)

## 2. Entry rule (exact)
TODO: e.g. "close > 200d SMA AND close <= 20d mean - 1.5 sd AND red day;
rank by z-score, take top 3."
NOTE: this default reversal rule FAILED its control arm on 2019-2026 data
(median edge over random: -0.27%). Running it on paper validates the
EXECUTION MACHINERY and measures fill quality. It is not expected to make
paper money. Write a different rule here if you have a different mechanism.

## 3. Target / stop / max hold
TODO: numbers, and where they came from (mechanism or out-of-sample data --
NOT profile_output.txt).

## 4. Universe
TODO: file + how built (top-N dollar ADV at window start).

## 5. Pass/fail gate
Expectancy per trade net of 3x-stressed costs, one-sided 95% block-bootstrap
lower bound > 0, minus 0.10-0.20%/trade survivorship haircut, on >= 300
resolved paper trades. No peeking before then.

## 6. Abandonment criterion
TODO: written BEFORE seeing results. e.g. "If after 300 resolved trades the
bootstrap lower bound is <= 0, this rule is dead and I will not revive it
with modifications."
