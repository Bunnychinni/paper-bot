<#
  Stage 1, in order. Windows PowerShell equivalent of run_all.sh.

  Usage:
      .\run_all.ps1
      .\run_all.ps1 -Years 6 -N 400

  Stops on any failure. Pauses at the EDGAR verification before spending
  the long earnings pull.
#>
param(
    [int]$Years = 6,
    [int]$N     = 400
)

$ErrorActionPreference = "Stop"

function Fail($msg) { Write-Host $msg -ForegroundColor Red; exit 1 }

# ---- environment ----
foreach ($v in @("APCA_API_KEY_ID","APCA_API_SECRET_KEY","SEC_UA")) {
    if (-not (Get-Item "env:$v" -ErrorAction SilentlyContinue)) {
        Fail "Missing environment variable: $v"
    }
}

if (-not $env:APCA_API_KEY_ID.StartsWith("PK")) {
    Fail "REFUSING: key does not start with PK. Those look like LIVE keys."
}
if ($env:SEC_UA -notmatch "@") {
    Fail "SEC_UA needs a real email address or SEC will 403 you."
}
Write-Host "paper keys OK" -ForegroundColor Green

# ---- 1/5 universe ----
Write-Host "`n=== 1/5 universe (3-6 min) ===" -ForegroundColor Cyan
python build_universe_file.py --max-symbols $N --years $Years --out universe.txt
if ($LASTEXITCODE -ne 0) { Fail "universe build failed" }

# ---- 2/5 EDGAR verification ----
Write-Host "`n=== 2/5 EDGAR verification (5 sec) -- STOP AND READ ===" -ForegroundColor Cyan
python build_earnings.py --symbols AAPL,MSFT,JPM --years 4 --out _verify.csv
if ($LASTEXITCODE -ne 0) { Fail "EDGAR fetch failed" }
Get-Content _verify.csv

Write-Host ""
Write-Host "AAPL and MSFT must be 'amc'.  JPM must be 'bmo'." -ForegroundColor Yellow
Write-Host "All three identical => parser broken. Open build_earnings.py," -ForegroundColor Yellow
Write-Host "flip SEC_TS_IS_UTC, and re-run this script." -ForegroundColor Yellow
$ok = Read-Host "`nVerification passed? [y/N]"
if ($ok -ne "y") { Write-Host "stopping"; exit 1 }

# ---- 3/5 full earnings ----
Write-Host "`n=== 3/5 full earnings pull (2-4 min) ===" -ForegroundColor Cyan
python build_earnings.py --from-universe universe.txt --years ($Years + 1) --out earnings.csv
if ($LASTEXITCODE -ne 0) { Fail "earnings pull failed" }

# ---- 4/5 profiler ----
Write-Host "`n=== 4/5 profiler (4-8 min) ===" -ForegroundColor Cyan
python mfe_profile.py --years $Years --universe universe.txt --earnings earnings.csv 2>&1 |
    Tee-Object -FilePath profile_output.txt
if ($LASTEXITCODE -ne 0) { Fail "profiler failed" }

# ---- 5/5 control arm ----
Write-Host "`n=== 5/5 control arm (1 min) ===" -ForegroundColor Cyan
python control_arm.py --years $Years --universe universe.txt --earnings earnings.csv 2>&1 |
    Tee-Object -FilePath control_output.txt

Write-Host "`nDone." -ForegroundColor Green
Write-Host "Send back profile_output.txt and control_output.txt."
Write-Host "Stage 1 is NOT run automatically -- target and stop must be chosen first."
