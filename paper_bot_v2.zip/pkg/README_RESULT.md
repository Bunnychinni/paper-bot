# STOP — READ THIS BEFORE TOUCHING ANY CODE IN THIS FOLDER

**Date closed: 2026-08-09**
**Result: the tested strategy FAILED. Do not restart it.**

You wrote this to yourself assuming total memory loss. Read all of it before running anything.

---

## 1. What was tested

**Candidate #1: short-term reversal in an uptrend.** Buy a liquid stock that has sold off sharply while still above its 200-day moving average. Hold 2–5 days.

The economic rationale was not arbitrary. Some sellers sell because they *must* — margin calls, fund redemptions, risk-limit breaches. They demand immediacy and pay for it. Price overshoots and reverts. You'd be paid to warehouse that risk. Documented: Lehmann (1990), Jegadeesh (1990), and Nagel (2012), which shows short-term reversal returns are essentially the return to liquidity provision and scale with VIX.

**Exact rule** (`signals.py::signal_reversal`): close above 200-day SMA; close ≥1.5 standard deviations below its 20-day mean; today closed down. Rank by most stretched, take top 3.

**Setup:** $1,000 cash account, 3 concurrent positions ~$300 each, T+1 settlement, Alpaca paper, US equities $10–100 with ADV > 2M shares, earnings excluded ±7 days.

**Window:** 2019-10-14 through 2026-08. Universe 382 symbols by dollar ADV at window start, of which **273 had earnings data** — 65 were ETFs, correctly excluded by the fail-closed rule.

---

## 2. The result

**It lost to random entries. Every single row.**

| Target | Signal hits | Random hits | Lift |
|---|---|---|---|
| 1.5% | 67.3% | 70.7% | **−3.4** |
| 2.0% | 59.6% | 62.3% | **−2.8** |
| 2.5% | 50.8% | 54.9% | **−4.1** |
| 3.0% | 43.4% | 47.4% | **−4.0** |
| 3.5% | 36.0% | 43.1% | **−7.1** |
| 4.0% | 30.7% | 38.8% | **−8.1** |
| 5.0% | 21.5% | 30.4% | **−8.8** |

**Median 5-day edge over random: −0.272%. Mean: −0.423%.**

Control = random entry days, same universe, same filters, same 3-per-day cap, same next-open entry.

Supporting numbers:
- 1,439 raw signals across 918 distinct entry dates (1.57/date) — healthy sample, mild clustering
- Median MFE 2.56%, median MAE −2.43% — nearly symmetric
- A 1.5% stop was hit **64.1%** of the time within 5 days
- The profiler's pre-written trigger fired: *"IF median MFE < 3%, the 4.0% target is not supported"*

**This is not a bug.** A silent filter would make signal ≈ control everywhere. These diverge consistently in one direction, monotonically widening with horizon.

**Survivorship makes it worse, not better.** Delisted names are absent, and those are disproportionately the ones that fell and never recovered — the trades that would have hurt most. The measured edge is an *optimistic* bound, and the optimistic bound is negative.

**Why it probably failed:** Nagel's liquidity-provision effect is strongest where liquidity is scarce and volatility high. The universe was screened to the ~382 most liquid US stocks over a mostly calm period — precisely where that compensation is thinnest and most competed away. The filter that made costs survivable at $1,000 removed the thing the strategy was harvesting.

---

## 3. What is contaminated about this window

**Read this twice. It is the whole point of the file.**

The 2019-10 → 2026-08 window is **burned for parameter selection**, not just for this one signal.

You have seen the MFE/MAE distribution for this universe. Any target, stop, or hold period you choose from now on is informed by that. That contaminates parameter selection **even for a completely new signal**, and no α-adjustment fixes it. It is not about how many tests you've run. It's about what you've looked at.

Specifically burned:
- Any variant of the reversal signal — inverting it, widening stops, adding a VIX condition, changing the z-threshold, changing the trend filter
- Any target/stop pair chosen by consulting `profile_output.txt`
- Any "let me just try 3 years instead of 6"

**Still clean on this window:** exactly one, maybe two, fully pre-registered hypotheses where the rule *and* every parameter is derived from a mechanism before you look at anything. See §5.

---

## 4. Directions considered and rejected (with reasons — don't redo this analysis)

**PEAD (post-earnings drift).** Rejected. Documented drift runs 20–60 days. At 3 slots × 40-day holds you generate ~20 trades/year, so ~120 over six years and ~40 in a 35% holdout. The expectancy gate needs 200–300. **You cannot power the test at the horizon where the effect exists, and at the horizon you can power, the effect isn't there.** Also needs consensus EPS (paid) and fights the ADV filter, since surviving drift concentrates in illiquid names.

**Reversal in thin / low-liquidity names.** Rejected on cost. Sub-$2M ADV names carry 30–80bps spreads vs the 3–10bps you filtered for. Round-trip cost goes from ~0.12% to 0.6–1.6%. At a 2.5% target / 2% stop that's a break-even win rate near **67%**. Nothing clears that.

**High-VIX conditioning.** Rejected as contaminated. Economically the most defensible variant, but it's a subset of data already examined. Only testable on data you haven't seen.

**The general finding, which is bigger than the one signal:** the liquidity level that keeps your costs survivable and the liquidity level where the mechanism lives point in opposite directions.

---

## 5. What a future you must pre-register before touching this again

Create `preregistration_YYYYMMDD.md` and commit or timestamp it **before running a single command.** It must contain, all specified in advance:

1. **The mechanism.** Why is someone on the other side losing money on purpose? If you can't name them, you have a pattern, not an edge.
2. **The exact entry rule**, as code, with every threshold fixed.
3. **Target, stop, max hold** — derived from the mechanism or from *out-of-sample* data. **Not from `profile_output.txt`.**
4. **Universe and date window**, and why.
5. **The pass/fail gate**, unchanged: expectancy per trade net of 3x-stressed cost, one-sided 95% block-bootstrap lower bound > 0, minus a 0.10–0.20%/trade survivorship haircut.
6. **What result would make you abandon it.** Write this down before you know the answer.

Then, in order: `mfe_profile.py` → `control_arm.py` → **read the control arm first** → only then `run_stage1.py`.

**The control arm is the kill switch. If median edge over random is near zero or negative, stop. Don't proceed to Stage 1 to "see what happens."**

If you catch yourself consulting old output to pick a number, you've spent the budget and you need fresh data.

---

## 6. Out-of-sample data: what's actually available

Alpaca's docs conflict — the SDK page says "over 5 years," the marketing page says "7+ years." Neither was verified. Your run reached back to **2019-10-14** successfully.

**Settle it empirically** (10 seconds, needs your keys set):

```powershell
python -c "import os;from datetime import datetime;from alpaca.data.historical import StockHistoricalDataClient;from alpaca.data.requests import StockBarsRequest;from alpaca.data.timeframe import TimeFrame;c=StockHistoricalDataClient(os.environ['APCA_API_KEY_ID'],os.environ['APCA_API_SECRET_KEY'])
for y in (2010,2013,2015,2016,2017,2018):
    try:
        b=c.get_stock_bars(StockBarsRequest(symbol_or_symbols=['AAPL'],timeframe=TimeFrame.Day,start=datetime(y,1,4),end=datetime(y,3,1)))
        n=len(b.data.get('AAPL',[]))
        print(y,'->',n,'bars', '' if n else '(EMPTY)')
    except Exception as e: print(y,'-> ERROR',str(e)[:70])"
```

**Set expectations.** Alpaca's equity history is generally understood to begin around **2016**. If so, your clean out-of-sample window is roughly **2016-01 → 2019-10 — about 3.5 years, not the 2010–2018 you hoped for.** Caveats if you use it:

- It's a single regime: late-2010s bull market, low volatility, ZIRP. Mean reversion behaved differently there. A pass on that window is weak evidence for today.
- 3.5 years at ~250 trades/year ≈ 875 raw trades. Enough to power the gate, barely.
- Survivorship is **worse** the further back you go.
- You must rebuild `universe.txt` with `--years` set so `select_by_liquidity` ranks at *that* window's start. Reusing the current file is forward-looking and invalidates the test.
- If bars only reach 2016, **do not overlap into 2019-10+.** The moment you touch this window again it stops being out-of-sample.

**The other clean source is time.** ~250 signals/year at capacity means **12–18 months** of forward paper logging to accumulate 200–300 independent trades. That's the real clock on anything you can't test historically.

---

## 7. What you actually have

The infrastructure is the asset. It is validated and it survived contact with a real negative result.

| File | What it does |
|---|---|
| `control_arm.py` | Random-entry baseline. **The kill switch. Always run it.** |
| `mfe_profile.py` | MFE/MAE with no target, stop, or capital. Nothing in it knows a gate exists. |
| `bootstrap.py` | Block bootstrap by entry date, measured ICC, expectancy gate, regime split |
| `stage1_backtest.py` | Cash account, T+1 settlement, gap exits separated from clean stops |
| `cost_model.py` | Per-price round-trip cost, aggressive vs passive, 3x slippage stress |
| `gate_power.py` | Sample size the gate needs |
| `build_earnings.py` | SEC EDGAR 8-K Item 2.02 → earnings dates. Free, verified working. |
| `build_universe_file.py` | Top-N by dollar ADV at window start (not alphabetical, not forward-looking) |
| `test_dryrun.py` | Full pipeline on synthetic data, no API key. **Run first after any gap.** |

Verified working: EDGAR parser (AAPL/MSFT `amc`, JPM `bmo` — the DST bug is fixed and `SEC_TS_IS_UTC = True` is correct), ICC estimator recovers known ρ, gate fails closed on noise, no order path anywhere (`grep submit_order` returns nothing).

**Setup after a gap:**
```powershell
cd <this folder>
py -3.13 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python test_dryrun.py        # expect FAIL on the gate — that's correct
```
Then set `APCA_API_KEY_ID`, `APCA_API_SECRET_KEY`, `SEC_UA`. Keys are session-only; they vanish when the window closes. **Never paste them into a chat window or a screenshot.**

---

## 8. The conclusion you reached, so you don't re-derive it

**Capital was the binding constraint — but not because $1,000 is too small to trade.**

$1,000 → $300 positions → sub-$100 shares → tight spreads → ADV > 2M → the ~400 most liquid stocks in America. That is the most efficiently priced set of securities on the planet. Any edge surviving there is smaller than your 0.12% round-trip cost or requires capabilities you don't have.

The constraints, in order of how hard they bind:

1. **Fixed costs as a share of capital.** A $50/month data feed is 60%/year of $1,000. This makes every paid input irrational — and paid inputs are where the remaining edges are. **This is the real bind, and it does not relax at $10,000.** It starts relaxing near **$60,000**, where $50/month is under 1% annual drag.
2. The cost floor forces targets ≥2%, which forces multi-day holds, which forces small samples.
3. Small samples mean every test takes a year or more.
4. Position sizing itself — genuinely the least of them.

**The highest-EV use of $1,000 in markets is not to trade it.** It's to keep accumulating from income until fixed costs stop dominating, while testing on paper where being wrong is free.

You found out in a few days, for zero dollars, what usually takes eighteen months and real money. Most retail traders never build a control arm, never separate gap exits from clean stops, never compute a break-even that includes round-trip cost, and never pre-commit to a gate that can fail. **The infrastructure and the epistemics transfer. The $1,000 was never going to.**

---

## 9. If you're about to start testing something right now

Don't — not today. The urge to immediately try the next thing is strongest right after a negative result, and it is the same urge that produces overfitting. Write the pre-registration first. If the hypothesis still looks good in a week, run it.

And if you find yourself reasoning toward *"the reversal signal would work if only I..."* — reread §2 and §3. You already tested that. It lost to random.
