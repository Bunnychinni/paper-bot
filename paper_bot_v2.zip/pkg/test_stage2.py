"""Stage 2 mechanics test: logbook + context, no network, no keys."""
import os, json
from datetime import date, timedelta
import logbook as LB, context as CTX

if os.path.exists("_t.db"): os.remove("_t.db")
con = LB.connect("_t.db")

# synthetic benchmark bars
def mk(n, vol):
    import random; random.seed(4); p=500.0; out=[]; d=date(2025,1,2)
    for _ in range(n):
        c=p*(1+random.gauss(0.0003,vol)); out.append(dict(date=d,open=c,high=c,low=c,close=c,volume=1e7)); p=c; d+=timedelta(days=1)
    return out
bench={"SPY":mk(400,0.010),"QQQ":mk(400,0.012),"VIXY":mk(400,0.030)}

ctx = CTX.build_context(bench, date(2026,8,10), macro_path="macro_calendar.csv")
print("context:"); [print("  ",k,"=",v) for k,v in ctx.items() if k!="notes"]
for n in ctx["notes"]: print("   note:",n)

rid = LB.start_run(con,"abc123","preregistration.md",ctx,382,382)
for i,s in enumerate(["AAPL","MSFT","NVDA"],1):
    LB.log_signal(con,rid,dict(signal_date="2026-08-10",symbol=s,rank=i,ref_close=100.0,
        intended_entry=100.0,target=102.5,stop=98.0,shares=3.0,notional=300.0,
        size_multiplier=ctx["size_multiplier"],reason="test",features={"z20":-1.7}))
LB.finish_run(con,rid,3)
LB.record_outcome(con,1,actual_entry=100.1,exit_price=102.5,exit_date="2026-08-13",
                  exit_reason="target",ret_pct=2.40,mfe5=2.8,mae5=-0.9,held_days=3,entry_slip_bps=10)
print("\nunresolved:",len(LB.unresolved(con,min_age_days=0)))
LB.print_progress(con)
os.remove("_t.db")
